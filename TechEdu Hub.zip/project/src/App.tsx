import React, { Suspense } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import LoadingSpinner from './components/LoadingSpinner';
import ScrollProgress from './components/Layout/ScrollProgress';
import SearchBar from './components/UI/SearchBar';
import PageTransition from './components/Layout/PageTransition';
import DirectLearningSection from './components/DirectLearningSection';
import QuickAccessNotes from './components/QuickAccessNotes';

const ProfileSection = React.lazy(() => import('./components/ProfileSection'));
const TabSection = React.lazy(() => import('./components/TabSection'));
const NotesSection = React.lazy(() => import('./components/NotesSection'));
const Footer = React.lazy(() => import('./components/Footer'));

const App = () => {
  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-gray-900">
        <ScrollProgress />
        <Navbar />
        <div className="fixed top-20 left-1/2 -translate-x-1/2 w-full max-w-xl px-4 z-40">
          <SearchBar />
        </div>
        <Hero />
        <Suspense fallback={<LoadingSpinner />}>
          <DirectLearningSection />
          <QuickAccessNotes />
          <ProfileSection />
          <NotesSection />
          <TabSection />
          <Footer />
        </Suspense>
      </div>
    </PageTransition>
  );
}

export default App;