import React, { useState, Suspense } from 'react';
import { BookOpen, Code2, Brain, Youtube, Laptop, GraduationCap, Globe, Server, Wrench, FileText, Bot } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import LoadingSpinner from './LoadingSpinner';

const ResourceSection = React.lazy(() => import('./ResourceSection'));
const SecuritySection = React.lazy(() => import('./SecuritySection'));
const BTechSection = React.lazy(() => import('./BTechSection'));
const CompilerSection = React.lazy(() => import('./CompilerSection'));
const BeginnerSection = React.lazy(() => import('./BeginnerSection'));
const IndianResourcesSection = React.lazy(() => import('./IndianResourcesSection'));
const OnlineCourseSection = React.lazy(() => import('./OnlineCourseSection'));

const TabSection = () => {
  const [activeTab, setActiveTab] = useState('all');
  const [isLoading, setIsLoading] = useState(false);

  const tabs = [
    { id: 'all', label: 'All Resources', icon: <BookOpen className="w-4 h-4" /> },
    { id: 'hindi', label: 'हिंदी Resources', icon: <Globe className="w-4 h-4" /> },
    { id: 'courses', label: 'Free Courses', icon: <GraduationCap className="w-4 h-4" /> },
    { id: 'tools', label: 'Dev Tools', icon: <Wrench className="w-4 h-4" /> },
    { id: 'notes', label: 'Study Notes', icon: <FileText className="w-4 h-4" /> },
    { id: 'ai', label: 'AI Tools', icon: <Bot className="w-4 h-4" /> },
    { id: 'compiler', label: 'Online IDE', icon: <Code2 className="w-4 h-4" /> }
  ];

  const handleTabChange = (tabId: string) => {
    setIsLoading(true);
    setActiveTab(tabId);
    setTimeout(() => setIsLoading(false), 500);
  };

  const renderContent = () => {
    if (isLoading) {
      return <LoadingSpinner />;
    }

    switch (activeTab) {
      case 'hindi':
        return (
          <Suspense fallback={<LoadingSpinner />}>
            <IndianResourcesSection />
          </Suspense>
        );
      case 'courses':
        return (
          <Suspense fallback={<LoadingSpinner />}>
            <OnlineCourseSection />
          </Suspense>
        );
      case 'tools':
        return (
          <Suspense fallback={<LoadingSpinner />}>
            <ResourceSection />
          </Suspense>
        );
      case 'compiler':
        return (
          <Suspense fallback={<LoadingSpinner />}>
            <CompilerSection />
          </Suspense>
        );
      case 'notes':
        return (
          <Suspense fallback={<LoadingSpinner />}>
            <BTechSection />
          </Suspense>
        );
      case 'ai':
        return (
          <Suspense fallback={<LoadingSpinner />}>
            <SecuritySection />
          </Suspense>
        );
      default:
        return (
          <Suspense fallback={<LoadingSpinner />}>
            <div className="space-y-20">
              <OnlineCourseSection />
              <IndianResourcesSection />
              <ResourceSection />
              <CompilerSection />
            </div>
          </Suspense>
        );
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <motion.div
        className="flex flex-wrap justify-center gap-4 mb-12"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {tabs.map((tab, index) => (
          <motion.button
            key={tab.id}
            onClick={() => handleTabChange(tab.id)}
            className={`flex items-center space-x-2 px-6 py-3 rounded-full transition-all duration-300 ${
              activeTab === tab.id
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/25'
                : 'bg-gray-800/50 text-gray-400 hover:bg-gray-700/50 hover:text-gray-300'
            }`}
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </motion.button>
        ))}
      </motion.div>

      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          className="min-h-screen"
        >
          {renderContent()}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default TabSection;