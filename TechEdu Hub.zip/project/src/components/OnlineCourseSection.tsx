import React from 'react';
import { BookOpen, Code2, Brain, Youtube, GraduationCap } from 'lucide-react';

const OnlineCourseSection = () => {
  const courses = [
    {
      title: 'Computer Science Fundamentals',
      icon: <BookOpen className="w-6 h-6 text-indigo-400" />,
      courses: [
        {
          name: 'CS50: Introduction to Computer Science',
          provider: 'Harvard University',
          url: 'https://cs50.harvard.edu/x/',
          logo: 'https://cs50.harvard.edu/x/2024/favicon.ico'
        },
        {
          name: 'Introduction to Python Programming',
          provider: 'MIT OpenCourseWare',
          url: 'https://ocw.mit.edu/courses/6-0001-introduction-to-computer-science-and-programming-in-python-fall-2016/',
          logo: 'https://ocw.mit.edu/favicon.ico'
        },
        {
          name: 'Data Structures and Algorithms',
          provider: 'Stanford Online',
          url: 'https://online.stanford.edu/courses/soe-ycsalgorithms1-algorithms-design-and-analysis-part-1',
          logo: 'https://www.stanford.edu/favicon.ico'
        }
      ]
    },
    {
      title: 'Web Development',
      icon: <Code2 className="w-6 h-6 text-indigo-400" />,
      courses: [
        {
          name: 'Full Stack Open',
          provider: 'University of Helsinki',
          url: 'https://fullstackopen.com/',
          logo: 'https://fullstackopen.com/favicon.ico'
        },
        {
          name: 'Modern JavaScript',
          provider: 'JavaScript.info',
          url: 'https://javascript.info/',
          logo: 'https://javascript.info/favicon.ico'
        },
        {
          name: 'React Development',
          provider: 'React.dev',
          url: 'https://react.dev/learn',
          logo: 'https://react.dev/favicon.ico'
        }
      ]
    },
    {
      title: 'Machine Learning & AI',
      icon: <Brain className="w-6 h-6 text-indigo-400" />,
      courses: [
        {
          name: 'Machine Learning',
          provider: 'Stanford Online',
          url: 'https://www.coursera.org/learn/machine-learning',
          logo: 'https://d3njjcbhbojbot.cloudfront.net/web/images/favicons/favicon-v2-96x96.png'
        },
        {
          name: 'Deep Learning Specialization',
          provider: 'DeepLearning.AI',
          url: 'https://www.coursera.org/specializations/deep-learning',
          logo: 'https://d3njjcbhbojbot.cloudfront.net/web/images/favicons/favicon-v2-96x96.png'
        },
        {
          name: 'AI for Everyone',
          provider: 'DeepLearning.AI',
          url: 'https://www.coursera.org/learn/ai-for-everyone',
          logo: 'https://d3njjcbhbojbot.cloudfront.net/web/images/favicons/favicon-v2-96x96.png'
        }
      ]
    },
    {
      title: 'Certifications & Career',
      icon: <GraduationCap className="w-6 h-6 text-indigo-400" />,
      courses: [
        {
          name: 'Google IT Support',
          provider: 'Google',
          url: 'https://www.coursera.org/professional-certificates/google-it-support',
          logo: 'https://d3njjcbhbojbot.cloudfront.net/web/images/favicons/favicon-v2-96x96.png'
        },
        {
          name: 'AWS Cloud Practitioner',
          provider: 'Amazon',
          url: 'https://aws.amazon.com/training/digital/aws-cloud-practitioner-essentials/',
          logo: 'https://aws.amazon.com/favicon.ico'
        },
        {
          name: 'Microsoft Azure Fundamentals',
          provider: 'Microsoft',
          url: 'https://learn.microsoft.com/en-us/training/paths/az-900-describe-cloud-concepts/',
          logo: 'https://learn.microsoft.com/favicon.ico'
        }
      ]
    }
  ];

  return (
    <section id="courses" className="py-12">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {courses.map((category, index) => (
            <div key={index} className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 hover:shadow-xl transition-all duration-300 border border-gray-700/50">
              <div className="flex items-center mb-4">
                <div className="p-2 bg-indigo-500/10 rounded-lg">
                  {category.icon}
                </div>
                <h3 className="text-xl font-semibold text-white ml-3">{category.title}</h3>
              </div>
              <ul className="space-y-4">
                {category.courses.map((course, courseIndex) => (
                  <li key={courseIndex} className="bg-gray-700/30 rounded-lg p-4">
                    <a
                      href={course.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group"
                    >
                      <div className="flex items-start space-x-3">
                        <img 
                          src={course.logo} 
                          alt={`${course.provider} logo`} 
                          className="w-6 h-6 rounded-sm mt-1 group-hover:scale-110 transition-transform duration-200"
                        />
                        <div>
                          <h4 className="text-indigo-300 group-hover:text-indigo-200 font-medium transition-colors duration-200">
                            {course.name}
                          </h4>
                          <p className="text-gray-400 text-sm">{course.provider}</p>
                        </div>
                      </div>
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default OnlineCourseSection;