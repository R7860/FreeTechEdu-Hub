import React from 'react';
import { BookOpen, Code2, Brain, Calculator, Database, Network, Server, Shield, Globe, Cpu } from 'lucide-react';

const BTechSection = () => {
  const btechResources = [
    {
      title: 'Core Computing',
      icon: <Cpu className="w-6 h-6 text-indigo-400" />,
      links: [
        { 
          name: 'Computer Architecture',
          url: 'https://www.coursera.org/learn/build-a-computer',
          logo: 'https://d3njjcbhbojbot.cloudfront.net/web/images/favicons/favicon-v2-96x96.png'
        },
        { 
          name: 'Operating Systems',
          url: 'https://www.edx.org/learn/operating-systems',
          logo: 'https://www.edx.org/favicon.ico'
        },
        { 
          name: 'Computer Systems',
          url: 'https://www.cs.cmu.edu/~213/',
          logo: 'https://www.cmu.edu/favicon.ico'
        },
        {
          name: 'Digital Logic',
          url: 'https://www.nand2tetris.org/',
          logo: 'https://www.nand2tetris.org/favicon.ico'
        }
      ]
    },
    {
      title: 'Programming & Development',
      icon: <Code2 className="w-6 h-6 text-indigo-400" />,
      links: [
        { 
          name: 'Advanced Python',
          url: 'https://realpython.com/',
          logo: 'https://realpython.com/favicon.ico'
        },
        { 
          name: 'Java Masterclass',
          url: 'https://java-programming.mooc.fi/',
          logo: 'https://java-programming.mooc.fi/favicon.ico'
        },
        { 
          name: 'Full Stack Development',
          url: 'https://fullstackopen.com/en/',
          logo: 'https://fullstackopen.com/favicon.ico'
        },
        {
          name: 'Data Structures & Algorithms',
          url: 'https://www.geeksforgeeks.org/data-structures/',
          logo: 'https://www.geeksforgeeks.org/favicon.ico'
        }
      ]
    },
    {
      title: 'Database Systems',
      icon: <Database className="w-6 h-6 text-indigo-400" />,
      links: [
        { 
          name: 'Advanced SQL',
          url: 'https://mode.com/sql-tutorial/',
          logo: 'https://mode.com/favicon.ico'
        },
        { 
          name: 'Database Design',
          url: 'https://www.mysqltutorial.org/',
          logo: 'https://www.mysqltutorial.org/favicon.ico'
        },
        { 
          name: 'NoSQL with MongoDB',
          url: 'https://university.mongodb.com/',
          logo: 'https://university.mongodb.com/favicon.ico'
        },
        {
          name: 'Database Administration',
          url: 'https://www.postgresql.org/docs/online-resources/',
          logo: 'https://www.postgresql.org/favicon.ico'
        }
      ]
    },
    {
      title: 'Networking',
      icon: <Network className="w-6 h-6 text-indigo-400" />,
      links: [
        { 
          name: 'Computer Networks',
          url: 'https://gaia.cs.umass.edu/kurose_ross/online_lectures.htm',
          logo: 'https://www.umass.edu/favicon.ico'
        },
        { 
          name: 'Network Security',
          url: 'https://www.cybrary.it/course/comptia-network-plus/',
          logo: 'https://www.cybrary.it/favicon.ico'
        },
        { 
          name: 'Cisco Networking',
          url: 'https://www.netacad.com/',
          logo: 'https://www.netacad.com/favicon.ico'
        },
        {
          name: 'Network Protocols',
          url: 'https://www.protocols.com/',
          logo: 'https://www.protocols.com/favicon.ico'
        }
      ]
    },
    {
      title: 'Software Engineering',
      icon: <Brain className="w-6 h-6 text-indigo-400" />,
      links: [
        { 
          name: 'Software Design Patterns',
          url: 'https://refactoring.guru/design-patterns',
          logo: 'https://refactoring.guru/favicon.ico'
        },
        { 
          name: 'Clean Code Principles',
          url: 'https://clean-code-developer.com/',
          logo: 'https://clean-code-developer.com/favicon.ico'
        },
        { 
          name: 'Agile Development',
          url: 'https://www.atlassian.com/agile',
          logo: 'https://www.atlassian.com/favicon.ico'
        },
        {
          name: 'System Design',
          url: 'https://github.com/donnemartin/system-design-primer',
          logo: 'https://github.com/favicon.ico'
        }
      ]
    },
    {
      title: 'Cloud Computing',
      icon: <Server className="w-6 h-6 text-indigo-400" />,
      links: [
        { 
          name: 'AWS Fundamentals',
          url: 'https://aws.amazon.com/getting-started/',
          logo: 'https://aws.amazon.com/favicon.ico'
        },
        { 
          name: 'Azure Essentials',
          url: 'https://learn.microsoft.com/en-us/azure/',
          logo: 'https://learn.microsoft.com/favicon.ico'
        },
        { 
          name: 'Google Cloud',
          url: 'https://cloud.google.com/training',
          logo: 'https://cloud.google.com/favicon.ico'
        },
        {
          name: 'DevOps Practices',
          url: 'https://www.devops.com/',
          logo: 'https://www.devops.com/favicon.ico'
        }
      ]
    },
    {
      title: 'Cybersecurity',
      icon: <Shield className="w-6 h-6 text-indigo-400" />,
      links: [
        { 
          name: 'Web Security',
          url: 'https://portswigger.net/web-security',
          logo: 'https://portswigger.net/favicon.ico'
        },
        { 
          name: 'Cryptography',
          url: 'https://cryptohack.org/',
          logo: 'https://cryptohack.org/favicon.ico'
        },
        { 
          name: 'Ethical Hacking',
          url: 'https://www.hackthebox.com/',
          logo: 'https://www.hackthebox.com/favicon.ico'
        },
        {
          name: 'Security Certifications',
          url: 'https://www.comptia.org/certifications/security',
          logo: 'https://www.comptia.org/favicon.ico'
        }
      ]
    },
    {
      title: 'Web Technologies',
      icon: <Globe className="w-6 h-6 text-indigo-400" />,
      links: [
        { 
          name: 'Modern JavaScript',
          url: 'https://javascript.info/',
          logo: 'https://javascript.info/favicon.ico'
        },
        { 
          name: 'React Development',
          url: 'https://react.dev/',
          logo: 'https://react.dev/favicon.ico'
        },
        { 
          name: 'Web Performance',
          url: 'https://web.dev/learn-web-vitals/',
          logo: 'https://web.dev/favicon.ico'
        },
        {
          name: 'Progressive Web Apps',
          url: 'https://web.dev/progressive-web-apps/',
          logo: 'https://web.dev/favicon.ico'
        }
      ]
    }
  ];

  return (
    <section id="btech" className="py-20 bg-gradient-to-b from-gray-900 via-gray-800 to-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <span className="inline-block px-4 py-1 bg-indigo-500/10 text-indigo-400 rounded-full text-sm font-semibold mb-4">
            BTECH COMPUTING LEVEL 3
          </span>
          <h2 className="text-4xl font-bold text-white mb-4">
            Comprehensive Learning Resources
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Curated collection of high-quality resources covering all aspects of BTech Computing curriculum
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {btechResources.map((category, index) => (
            <div key={index} className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 hover:shadow-xl transition-all duration-300 border border-gray-700/50 group hover:border-indigo-500/50">
              <div className="flex items-center mb-4">
                <div className="p-2 bg-indigo-500/10 rounded-lg group-hover:bg-indigo-500/20 transition-colors duration-300">
                  {category.icon}
                </div>
                <h3 className="text-xl font-semibold text-white ml-3">{category.title}</h3>
              </div>
              <ul className="space-y-3">
                {category.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center space-x-2 text-indigo-300 hover:text-indigo-200 transition-colors duration-200 group"
                    >
                      <img 
                        src={link.logo} 
                        alt={`${link.name} logo`} 
                        className="w-4 h-4 rounded-sm group-hover:scale-110 transition-transform duration-200"
                      />
                      <span>{link.name}</span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BTechSection;