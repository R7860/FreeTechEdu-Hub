import React from 'react';
import { Shield, Lock, Terminal, FileCode } from 'lucide-react';

const SecuritySection = () => {
  const securityResources = [
    {
      title: 'Cybersecurity Learning',
      icon: <Shield className="w-6 h-6 text-indigo-400" />,
      links: [
        { name: 'TryHackMe', url: 'https://tryhackme.com' },
        { name: 'HackTheBox', url: 'https://www.hackthebox.com' },
        { name: 'PortSwigger Web Security Academy', url: 'https://portswigger.net/web-security' },
      ]
    },
    {
      title: 'CTF Platforms',
      icon: <Lock className="w-6 h-6 text-indigo-400" />,
      links: [
        { name: 'PicoCTF', url: 'https://picoctf.org' },
        { name: 'CTFtime', url: 'https://ctftime.org' },
        { name: 'VulnHub', url: 'https://www.vulnhub.com' },
      ]
    },
    {
      title: 'Security Tools',
      icon: <Terminal className="w-6 h-6 text-indigo-400" />,
      links: [
        { name: 'OWASP', url: 'https://owasp.org' },
        { name: 'Metasploit', url: 'https://www.metasploit.com' },
        { name: 'Wireshark', url: 'https://www.wireshark.org' },
      ]
    },
    {
      title: 'Practice Labs',
      icon: <FileCode className="w-6 h-6 text-indigo-400" />,
      links: [
        { name: 'Damn Vulnerable Web App', url: 'https://dvwa.co.uk' },
        { name: 'OWASP Juice Shop', url: 'https://owasp.org/www-project-juice-shop' },
        { name: 'WebGoat', url: 'https://owasp.org/www-project-webgoat' },
      ]
    }
  ];

  return (
    <section id="security" className="py-20 bg-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-white text-center mb-12">
          Cybersecurity Resources
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {securityResources.map((category, index) => (
            <div key={index} className="bg-gray-900 rounded-xl p-6 hover:shadow-xl transition-all duration-300">
              <div className="flex items-center mb-4">
                {category.icon}
                <h3 className="text-xl font-semibold text-white ml-2">{category.title}</h3>
              </div>
              <ul className="space-y-3">
                {category.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="resource-link"
                    >
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SecuritySection;