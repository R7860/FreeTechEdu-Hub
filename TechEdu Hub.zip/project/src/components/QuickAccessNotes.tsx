import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Code2, BookOpen, Brain, Shield, ChevronRight } from 'lucide-react';
import CodePreview from './CodePreview';

const QuickAccessNotes = () => {
  const [selectedTopic, setSelectedTopic] = useState('dsa');

  const topics = {
    dsa: {
      title: "Data Structures & Algorithms",
      icon: <Code2 className="w-6 h-6" />,
      content: [
        {
          title: "Arrays & Strings",
          description: "Fundamental data structures for storing sequential data",
          code: `// Two Pointer Technique
function twoSum(nums, target) {
  let left = 0;
  let right = nums.length - 1;
  
  while (left < right) {
    const sum = nums[left] + nums[right];
    if (sum === target) return [left, right];
    if (sum < target) left++;
    else right--;
  }
  return [];
}`,
          notes: [
            "Time Complexity: O(n) for linear search",
            "Space Complexity: O(1) for in-place operations",
            "Common techniques: Two pointers, Sliding window",
            "Best for: Sequential access patterns"
          ]
        },
        {
          title: "Binary Trees",
          description: "Hierarchical data structure with at most two children per node",
          code: `class TreeNode {
  constructor(val) {
    this.val = val;
    this.left = null;
    this.right = null;
  }
}

function inorderTraversal(root) {
  const result = [];
  
  function traverse(node) {
    if (!node) return;
    traverse(node.left);
    result.push(node.val);
    traverse(node.right);
  }
  
  traverse(root);
  return result;
}`,
          notes: [
            "Traversals: Inorder, Preorder, Postorder",
            "Perfect Binary Tree: 2^h - 1 nodes",
            "Complete Binary Tree: Filled left to right",
            "Applications: Expression trees, Huffman coding"
          ]
        }
      ]
    },
    system: {
      title: "Operating Systems",
      icon: <Brain className="w-6 h-6" />,
      content: [
        {
          title: "Process Management",
          description: "Understanding process states and scheduling",
          code: `// Process Control Block Structure
struct PCB {
  int process_id;
  ProcessState state;
  int program_counter;
  int cpu_registers[REG_COUNT];
  int memory_limits;
  // More fields...
};`,
          notes: [
            "Process States: New, Ready, Running, Waiting, Terminated",
            "Context Switching: Saving and restoring process state",
            "Scheduling Algorithms: FCFS, SJF, Round Robin",
            "CPU Burst vs I/O Burst cycles"
          ]
        }
      ]
    },
    security: {
      title: "Cybersecurity",
      icon: <Shield className="w-6 h-6" />,
      content: [
        {
          title: "Web Security",
          description: "Common vulnerabilities and protection mechanisms",
          code: `// XSS Prevention Example
function escapeHtml(unsafe) {
  return unsafe
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}`,
          notes: [
            "OWASP Top 10 Vulnerabilities",
            "SQL Injection Prevention",
            "Cross-Site Scripting (XSS) Types",
            "CSRF Protection Mechanisms"
          ]
        }
      ]
    }
  };

  return (
    <section className="py-20 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold text-white mb-4">Quick Access Study Notes</h2>
          <p className="text-gray-400">Comprehensive notes with practical examples</p>
        </motion.div>

        <div className="flex flex-wrap justify-center gap-4 mb-8">
          {Object.entries(topics).map(([key, topic]) => (
            <motion.button
              key={key}
              onClick={() => setSelectedTopic(key)}
              className={`flex items-center space-x-2 px-6 py-3 rounded-full transition-all ${
                selectedTopic === key
                  ? 'bg-indigo-600 text-white'
                  : 'bg-gray-800/50 text-gray-400 hover:bg-gray-700/50'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {topic.icon}
              <span>{topic.title}</span>
            </motion.button>
          ))}
        </div>

        <div className="space-y-8">
          {topics[selectedTopic].content.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-gray-800/50 rounded-xl p-6 backdrop-blur-sm border border-gray-700/50"
            >
              <h3 className="text-xl font-semibold text-white mb-2">{item.title}</h3>
              <p className="text-gray-300 mb-4">{item.description}</p>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <CodePreview
                    code={item.code}
                    language="javascript"
                    title="Implementation"
                  />
                </div>
                <div className="bg-gray-900/50 rounded-lg p-4">
                  <h4 className="text-white font-medium mb-3">Key Points:</h4>
                  <ul className="space-y-2">
                    {item.notes.map((note, i) => (
                      <li key={i} className="flex items-start text-gray-300">
                        <ChevronRight className="w-4 h-4 text-indigo-400 mt-1 mr-2 flex-shrink-0" />
                        <span>{note}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default QuickAccessNotes;