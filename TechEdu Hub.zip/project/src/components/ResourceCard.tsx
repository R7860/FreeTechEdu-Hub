import React from 'react';
import { ExternalLink } from 'lucide-react';

interface Link {
  title: string;
  url: string;
}

interface ResourceCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  links: Link[];
}

const ResourceCard: React.FC<ResourceCardProps> = ({ title, description, icon, links }) => {
  return (
    <div className="bg-gray-800 rounded-lg p-6 transform hover:scale-105 transition-transform duration-200">
      <div className="flex items-center mb-4">
        <div className="text-blue-400 mr-3">
          {icon}
        </div>
        <h3 className="text-xl font-semibold text-white">{title}</h3>
      </div>
      <p className="text-gray-400 mb-4">{description}</p>
      <ul className="space-y-2">
        {links.map((link, index) => (
          <li key={index}>
            <a
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center text-blue-400 hover:text-blue-300 transition-colors duration-200"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              {link.title}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ResourceCard;