import React from 'react';
import { motion } from 'framer-motion';
import { Star } from 'lucide-react';

const UserReviews = () => {
  const reviews = [
    {
      name: "Alex Chen",
      role: "CS Student",
      rating: 5,
      comment: "Incredible resource for learning! The tutorials are well-structured and easy to follow.",
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop"
    },
    {
      name: "Sarah Johnson",
      role: "Cybersecurity Expert",
      rating: 5,
      comment: "The cybersecurity resources here are top-notch. Highly recommended!",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop"
    },
    {
      name: "Michael Kumar",
      role: "Web Developer",
      rating: 5,
      comment: "Best platform for learning web development. The community is amazing!",
      avatar: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=100&h=100&fit=crop"
    }
  ];

  return (
    <div className="py-12">
      <motion.div
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="text-center mb-12">
          <h3 className="text-2xl font-bold text-white mb-2">What Our Users Say</h3>
          <p className="text-gray-400">Join thousands of satisfied learners</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {reviews.map((review, index) => (
            <motion.div
              key={index}
              className="bg-gray-800/40 backdrop-blur-sm rounded-xl p-6 border border-gray-700/50"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.02 }}
            >
              <div className="flex items-center mb-4">
                <img
                  src={review.avatar}
                  alt={review.name}
                  className="w-12 h-12 rounded-full mr-4"
                />
                <div>
                  <h4 className="text-white font-medium">{review.name}</h4>
                  <p className="text-gray-400 text-sm">{review.role}</p>
                </div>
              </div>
              <div className="flex mb-3">
                {[...Array(review.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-gray-300">{review.comment}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
};

export default UserReviews;