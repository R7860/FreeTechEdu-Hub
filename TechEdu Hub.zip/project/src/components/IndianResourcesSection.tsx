import React from 'react';
import { BookOpen, Code2, Brain, Youtube, Laptop, GraduationCap, Globe, Server } from 'lucide-react';

const IndianResourcesSection = () => {
  const indianResources = [
    {
      title: 'हिंदी में प्रोग्रामिंग कोर्स',
      icon: <Code2 className="w-6 h-6 text-indigo-400" />,
      links: [
        {
          name: 'Code with Harry (Hindi)',
          url: 'https://www.codewithharry.com/videos/',
          logo: 'https://www.codewithharry.com/favicon.ico'
        },
        {
          name: 'Apna College (DSA)',
          url: 'https://www.youtube.com/@ApnaCollegeOfficial',
          logo: 'https://www.youtube.com/favicon.ico'
        },
        {
          name: 'Love Babbar DSA Sheet',
          url: 'https://www.youtube.com/@LoveBabbar',
          logo: 'https://www.youtube.com/favicon.ico'
        },
        {
          name: 'Programming Pathshala',
          url: 'https://www.youtube.com/@ProgrammingPathshala',
          logo: 'https://www.youtube.com/favicon.ico'
        }
      ]
    },
    {
      title: 'कंप्यूटर साइंस फंडामेंटल्स',
      icon: <BookOpen className="w-6 h-6 text-indigo-400" />,
      links: [
        {
          name: 'NPTEL Courses (IIT)',
          url: 'https://nptel.ac.in/courses/106',
          logo: 'https://nptel.ac.in/favicon.ico'
        },
        {
          name: 'Unacademy (Free Lectures)',
          url: 'https://unacademy.com/goal/gate-cse/TMUVD',
          logo: 'https://static.uacdn.net/favicon.ico'
        },
        {
          name: 'Gate Smashers',
          url: 'https://www.youtube.com/@GateSmashers',
          logo: 'https://www.youtube.com/favicon.ico'
        },
        {
          name: 'Knowledge Gate',
          url: 'https://www.youtube.com/@KNOWLEDGEGATE',
          logo: 'https://www.youtube.com/favicon.ico'
        }
      ]
    },
    {
      title: 'वेब डेवलपमेंट',
      icon: <Globe className="w-6 h-6 text-indigo-400" />,
      links: [
        {
          name: 'Thapa Technical',
          url: 'https://www.youtube.com/@ThapaTechnical',
          logo: 'https://www.youtube.com/favicon.ico'
        },
        {
          name: 'Technical Thapa',
          url: 'https://www.thapatechnical.com/',
          logo: 'https://www.thapatechnical.com/favicon.ico'
        },
        {
          name: 'Chai aur Code',
          url: 'https://www.youtube.com/@chaiaurcode',
          logo: 'https://www.youtube.com/favicon.ico'
        },
        {
          name: 'FreeCodeCamp Hindi',
          url: 'https://www.youtube.com/@freeCodeCampHindi',
          logo: 'https://www.youtube.com/favicon.ico'
        }
      ]
    },
    {
      title: 'प्लेसमेंट प्रिपरेशन',
      icon: <GraduationCap className="w-6 h-6 text-indigo-400" />,
      links: [
        {
          name: 'GeeksforGeeks Hindi',
          url: 'https://www.geeksforgeeks.org/hindi/',
          logo: 'https://www.geeksforgeeks.org/favicon.ico'
        },
        {
          name: 'Pepcoding',
          url: 'https://www.pepcoding.com/',
          logo: 'https://www.pepcoding.com/favicon.ico'
        },
        {
          name: 'Striver Hindi',
          url: 'https://www.youtube.com/@takeUforwardHindi',
          logo: 'https://www.youtube.com/favicon.ico'
        },
        {
          name: 'InterviewBit Hindi',
          url: 'https://www.interviewbit.com/hindi/',
          logo: 'https://www.interviewbit.com/favicon.ico'
        }
      ]
    },
    {
      title: 'एआई और एमएल',
      icon: <Brain className="w-6 h-6 text-indigo-400" />,
      links: [
        {
          name: 'Krish Naik',
          url: 'https://www.youtube.com/@krishnaik06',
          logo: 'https://www.youtube.com/favicon.ico'
        },
        {
          name: 'iNeuron Intelligence',
          url: 'https://www.youtube.com/@iNeuroniNtelligence',
          logo: 'https://www.youtube.com/favicon.ico'
        },
        {
          name: 'Coding Blocks ML',
          url: 'https://www.youtube.com/@CodingBlocksIndia',
          logo: 'https://www.youtube.com/favicon.ico'
        },
        {
          name: 'Analytics Vidhya Hindi',
          url: 'https://www.analyticsvidhya.com/hindi/',
          logo: 'https://www.analyticsvidhya.com/favicon.ico'
        }
      ]
    },
    {
      title: 'प्रैक्टिस प्लेटफॉर्म्स',
      icon: <Laptop className="w-6 h-6 text-indigo-400" />,
      links: [
        {
          name: 'CodeChef Hindi',
          url: 'https://www.codechef.com/hindi/',
          logo: 'https://www.codechef.com/favicon.ico'
        },
        {
          name: 'HackerRank Hindi',
          url: 'https://www.hackerrank.com/hindi',
          logo: 'https://www.hackerrank.com/favicon.ico'
        },
        {
          name: 'LeetCode Hindi',
          url: 'https://leetcode.com/discuss/general-discussion/1365665/leetcode-hindi-preparation',
          logo: 'https://leetcode.com/favicon.ico'
        },
        {
          name: 'CodeForces Hindi',
          url: 'https://codeforces.com/blog/entry/82144',
          logo: 'https://codeforces.com/favicon.ico'
        }
      ]
    },
    {
      title: 'मुफ्त कंपाइलर्स',
      icon: <Server className="w-6 h-6 text-indigo-400" />,
      links: [
        {
          name: 'OnlineGDB',
          url: 'https://www.onlinegdb.com/',
          logo: 'https://www.onlinegdb.com/favicon.ico'
        },
        {
          name: 'Programiz',
          url: 'https://www.programiz.com/python-programming/online-compiler/',
          logo: 'https://www.programiz.com/favicon.ico'
        },
        {
          name: 'JDoodle',
          url: 'https://www.jdoodle.com/',
          logo: 'https://www.jdoodle.com/favicon.ico'
        },
        {
          name: 'CodeSandbox',
          url: 'https://codesandbox.io/',
          logo: 'https://codesandbox.io/favicon.ico'
        }
      ]
    },
    {
      title: 'यूट्यूब चैनल्स',
      icon: <Youtube className="w-6 h-6 text-indigo-400" />,
      links: [
        {
          name: 'Jenny Lectures CS/IT',
          url: 'https://www.youtube.com/@JennyLecturesCSIT',
          logo: 'https://www.youtube.com/favicon.ico'
        },
        {
          name: 'Neso Academy',
          url: 'https://www.youtube.com/@nesoacademy',
          logo: 'https://www.youtube.com/favicon.ico'
        },
        {
          name: 'Anuj Bhaiya',
          url: 'https://www.youtube.com/@AnujBhaiya',
          logo: 'https://www.youtube.com/favicon.ico'
        },
        {
          name: 'Coding Ninjas Hindi',
          url: 'https://www.youtube.com/@CodingNinjasIndia',
          logo: 'https://www.youtube.com/favicon.ico'
        }
      ]
    }
  ];

  return (
    <section id="indian-resources" className="py-20 bg-gradient-to-b from-gray-800 via-gray-900 to-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <span className="inline-block px-4 py-1 bg-orange-500/10 text-orange-400 rounded-full text-sm font-semibold mb-4">
            भारतीय छात्रों के लिए
          </span>
          <h2 className="text-4xl font-bold text-white mb-4">
            हिंदी में कंप्यूटर साइंस रिसोर्सेज
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            भारतीय छात्रों के लिए हिंदी में मुफ्त कंप्यूटर साइंस शिक्षण संसाधन
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {indianResources.map((category, index) => (
            <div key={index} className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 hover:shadow-xl transition-all duration-300 border border-gray-700/50 group hover:border-orange-500/50">
              <div className="flex items-center mb-4">
                <div className="p-2 bg-orange-500/10 rounded-lg group-hover:bg-orange-500/20 transition-colors duration-300">
                  {category.icon}
                </div>
                <h3 className="text-lg font-semibold text-white ml-3">{category.title}</h3>
              </div>
              <ul className="space-y-3">
                {category.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center space-x-2 text-orange-300 hover:text-orange-200 transition-colors duration-200 group"
                    >
                      <img 
                        src={link.logo} 
                        alt={`${link.name} logo`} 
                        className="w-4 h-4 rounded-sm group-hover:scale-110 transition-transform duration-200"
                      />
                      <span>{link.name}</span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default IndianResourcesSection;