import React from 'react';
import { motion } from 'framer-motion';
import { Code2, BookOpen, Brain, Shield, Database, Network } from 'lucide-react';
import CodePreview from './CodePreview';

const DirectLearningSection = () => {
  const courses = [
    {
      title: "Web Development Fundamentals",
      icon: <Code2 className="w-6 h-6" />,
      content: {
        description: "Learn modern web development from scratch",
        topics: ["HTML5", "CSS3", "JavaScript", "React", "Node.js"],
        preview: `// Example React Component
function App() {
  const [count, setCount] = useState(0);
  return (
    <button onClick={() => setCount(count + 1)}>
      Count is {count}
    </button>
  );
}`
      }
    },
    {
      title: "Data Structures & Algorithms",
      icon: <BookOpen className="w-6 h-6" />,
      content: {
        description: "Master fundamental DSA concepts",
        topics: ["Arrays", "Linked Lists", "Trees", "Graphs", "Dynamic Programming"],
        preview: `// Binary Search Implementation
function binarySearch(arr, target) {
  let left = 0;
  let right = arr.length - 1;
  
  while (left <= right) {
    const mid = Math.floor((left + right) / 2);
    if (arr[mid] === target) return mid;
    if (arr[mid] < target) left = mid + 1;
    else right = mid - 1;
  }
  return -1;
}`
      }
    },
    {
      title: "Database Systems",
      icon: <Database className="w-6 h-6" />,
      content: {
        description: "Learn database design and management",
        topics: ["SQL", "NoSQL", "Indexing", "Transactions", "Optimization"],
        preview: `-- SQL Query Example
SELECT 
  users.name,
  COUNT(orders.id) as order_count
FROM users
LEFT JOIN orders ON users.id = orders.user_id
GROUP BY users.id
HAVING order_count > 5;`
      }
    },
    {
      title: "Network Programming",
      icon: <Network className="w-6 h-6" />,
      content: {
        description: "Understanding computer networks",
        topics: ["TCP/IP", "HTTP", "WebSockets", "Security", "APIs"],
        preview: `// WebSocket Server Example
const ws = new WebSocket('ws://localhost:8080');

ws.onmessage = (event) => {
  console.log('Received:', event.data);
};

ws.send(JSON.stringify({ type: 'hello' }));`
      }
    }
  ];

  return (
    <section className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold text-white mb-4">Start Learning Now</h2>
          <p className="text-gray-400">Access comprehensive courses with hands-on examples</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {courses.map((course, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-gray-800/50 rounded-xl p-6 backdrop-blur-sm border border-gray-700/50"
            >
              <div className="flex items-center mb-4">
                <div className="p-2 bg-indigo-500/10 rounded-lg text-indigo-400">
                  {course.icon}
                </div>
                <h3 className="text-xl font-semibold text-white ml-3">{course.title}</h3>
              </div>

              <p className="text-gray-300 mb-4">{course.content.description}</p>

              <div className="flex flex-wrap gap-2 mb-4">
                {course.content.topics.map((topic, i) => (
                  <span
                    key={i}
                    className="px-3 py-1 text-sm bg-indigo-500/10 text-indigo-300 rounded-full"
                  >
                    {topic}
                  </span>
                ))}
              </div>

              <CodePreview
                code={course.content.preview}
                language={course.title.includes("SQL") ? "sql" : "javascript"}
                title="Live Example"
              />

              <button className="mt-4 w-full py-2 px-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors">
                Start Learning
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default DirectLearningSection;