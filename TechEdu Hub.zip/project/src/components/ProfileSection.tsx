import React from 'react';
import { motion } from 'framer-motion';
import { Instagram, Github, Linkedin, Mail, Twitter, Globe, Users, BookOpen, Code } from 'lucide-react';
import UserStats from './UserStats';

const ProfileSection = () => {
  const socialLinks = [
    {
      icon: <Instagram className="w-6 h-6" />,
      url: 'https://www.instagram.com/itz__raihan_r43?igsh=cjVscHJkamZseGY0',
      label: 'Instagram',
      color: 'hover:text-pink-500'
    },
    {
      icon: <Github className="w-6 h-6" />,
      url: '#',
      label: 'GitHub',
      color: 'hover:text-gray-400'
    },
    {
      icon: <Linkedin className="w-6 h-6" />,
      url: '#',
      label: 'LinkedIn',
      color: 'hover:text-blue-500'
    },
    {
      icon: <Twitter className="w-6 h-6" />,
      url: '#',
      label: 'Twitter',
      color: 'hover:text-blue-400'
    }
  ];

  const achievements = [
    {
      icon: <Users className="w-6 h-6 text-blue-400" />,
      value: "1000+",
      label: "Students Mentored"
    },
    {
      icon: <BookOpen className="w-6 h-6 text-green-400" />,
      value: "50+",
      label: "Courses Created"
    },
    {
      icon: <Code className="w-6 h-6 text-purple-400" />,
      value: "24/7",
      label: "Support Available"
    }
  ];

  return (
    <section className="relative py-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-gray-900 via-gray-800 to-gray-900" />
      <motion.div
        className="absolute inset-0"
        style={{
          background: "radial-gradient(circle at 50% 50%, rgba(99, 102, 241, 0.1) 0%, transparent 50%)"
        }}
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.5, 0.3]
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 260, damping: 20 }}
            className="relative w-32 h-32 mx-auto mb-6"
          >
            <div className="absolute inset-0 rounded-full bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 animate-spin-slow" />
            <img
              src="https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=400&h=400&fit=crop"
              alt="Raihan"
              className="relative w-full h-full object-cover rounded-full p-1"
            />
          </motion.div>
          
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-3xl font-bold text-white mb-2"
          >
            Raihan
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-xl text-gray-400 mb-6"
          >
            Full Stack Developer & Cybersecurity Enthusiast
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="flex justify-center space-x-4"
          >
            {socialLinks.map((link, index) => (
              <motion.a
                key={link.label}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className={`p-3 rounded-full bg-gray-800/50 text-gray-400 backdrop-blur-sm transition-all duration-300 ${link.color}`}
                whileHover={{ scale: 1.1, rotate: 10 }}
                whileTap={{ scale: 0.9 }}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 + index * 0.1 }}
              >
                {link.icon}
              </motion.a>
            ))}
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto mb-12"
        >
          {achievements.map((achievement, index) => (
            <motion.div
              key={index}
              className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 text-center"
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.2 }}
            >
              <div className="flex justify-center mb-3">
                {achievement.icon}
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">{achievement.value}</h3>
              <p className="text-gray-400">{achievement.label}</p>
            </motion.div>
          ))}
        </motion.div>

        <UserStats />
      </div>
    </section>
  );
};

export default ProfileSection;