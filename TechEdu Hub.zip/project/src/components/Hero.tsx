import React from 'react';
import { GraduationCap, Code, Shield, ArrowDown } from 'lucide-react';
import { motion } from 'framer-motion';
import { TypeAnimation } from 'react-type-animation';

const Hero = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <div className="relative min-h-screen pt-20 pb-12 flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0">
        <motion.div
          className="absolute inset-0 bg-gradient-to-b from-gray-900 to-gray-800"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
        />
        <motion.div
          className="absolute inset-0"
          style={{
            background: "radial-gradient(circle at 50% 50%, rgba(99, 102, 241, 0.1) 0%, transparent 50%)"
          }}
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3]
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      </div>

      <motion.div
        className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div
          className="mb-8"
          variants={itemVariants}
        >
          <span className="inline-block px-4 py-1 bg-indigo-500/10 text-indigo-400 rounded-full text-sm font-semibold mb-4">
            Welcome to TechEdu Hub
          </span>
        </motion.div>

        <motion.h1
          className="text-4xl sm:text-6xl lg:text-7xl font-bold text-white mb-6"
          variants={itemVariants}
        >
          <span className="block mb-2">Master</span>
          <span className="text-gradient">
            <TypeAnimation
              sequence={[
                'Computer Science',
                2000,
                'Cybersecurity',
                2000,
                'Web Development',
                2000,
                'Machine Learning',
                2000
              ]}
              wrapper="span"
              speed={50}
              repeat={Infinity}
            />
          </span>
        </motion.h1>
        
        <motion.p
          className="text-xl sm:text-2xl text-gray-300 mb-12 max-w-3xl mx-auto"
          variants={itemVariants}
        >
          Your comprehensive learning platform for computer science and cybersecurity education. Start your journey today with our curated resources.
        </motion.p>
        
        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto mb-16"
          variants={containerVariants}
        >
          {[
            {
              icon: <GraduationCap className="w-12 h-12 text-indigo-400" />,
              title: "Expert-Led Learning",
              description: "Access comprehensive study materials curated by industry experts"
            },
            {
              icon: <Code className="w-12 h-12 text-indigo-400" />,
              title: "Hands-on Practice",
              description: "Interactive coding platforms and real-world projects"
            },
            {
              icon: <Shield className="w-12 h-12 text-indigo-400" />,
              title: "Career Growth",
              description: "Industry-relevant skills and certification preparation"
            }
          ].map((item, index) => (
            <motion.div
              key={index}
              className="bg-gray-800/50 backdrop-blur-sm p-8 rounded-xl border border-gray-700/50 hover:border-indigo-500/50 transition-all duration-300"
              variants={itemVariants}
              whileHover={{
                scale: 1.05,
                transition: { duration: 0.2 }
              }}
            >
              <motion.div
                className="flex justify-center mb-6"
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.5 }}
              >
                {item.icon}
              </motion.div>
              <h3 className="text-xl font-semibold text-white mb-3">{item.title}</h3>
              <p className="text-gray-400">{item.description}</p>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          className="flex justify-center"
          variants={itemVariants}
          animate={{
            y: [0, 10, 0]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <a
            href="#resources"
            className="text-gray-400 hover:text-white transition-colors duration-300"
          >
            <ArrowDown className="w-8 h-8" />
          </a>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default Hero;