import React from 'react';
import { BookOpen, Code2, Youtube, Monitor, Lightbulb, Rocket } from 'lucide-react';

const BeginnerSection = () => {
  const beginnerResources = [
    {
      title: 'Video Tutorials',
      icon: <Youtube className="w-6 h-6 text-indigo-400" />,
      links: [
        {
          name: 'CS50: Introduction to CS',
          url: 'https://cs50.harvard.edu/x/',
          logo: 'https://cs50.harvard.edu/x/2024/favicon.ico'
        },
        {
          name: 'FreeCodeCamp YouTube',
          url: 'https://www.youtube.com/c/freecodecamp',
          logo: 'https://www.youtube.com/favicon.ico'
        },
        {
          name: 'Traversy Media',
          url: 'https://www.youtube.com/c/TraversyMedia',
          logo: 'https://www.youtube.com/favicon.ico'
        }
      ]
    },
    {
      title: 'Interactive Learning',
      icon: <Rocket className="w-6 h-6 text-indigo-400" />,
      links: [
        {
          name: 'Codecademy',
          url: 'https://www.codecademy.com/learn',
          logo: 'https://www.codecademy.com/favicon.ico'
        },
        {
          name: 'Scrimba',
          url: 'https://scrimba.com/allcourses',
          logo: 'https://scrimba.com/favicon.ico'
        },
        {
          name: 'SoloLearn',
          url: 'https://www.sololearn.com/home',
          logo: 'https://www.sololearn.com/favicon.ico'
        }
      ]
    },
    {
      title: 'Project-Based Learning',
      icon: <Lightbulb className="w-6 h-6 text-indigo-400" />,
      links: [
        {
          name: 'The Odin Project',
          url: 'https://www.theodinproject.com',
          logo: 'https://www.theodinproject.com/favicon-32x32.png'
        },
        {
          name: 'Frontend Mentor',
          url: 'https://www.frontendmentor.io',
          logo: 'https://www.frontendmentor.io/favicon-32x32.png'
        },
        {
          name: 'JavaScript30',
          url: 'https://javascript30.com',
          logo: 'https://javascript30.com/favicon.ico'
        }
      ]
    },
    {
      title: 'Documentation & Guides',
      icon: <BookOpen className="w-6 h-6 text-indigo-400" />,
      links: [
        {
          name: 'MDN Web Docs',
          url: 'https://developer.mozilla.org',
          logo: 'https://developer.mozilla.org/favicon-48x48.png'
        },
        {
          name: 'DevDocs',
          url: 'https://devdocs.io',
          logo: 'https://devdocs.io/favicon.ico'
        },
        {
          name: 'Web.dev',
          url: 'https://web.dev/learn',
          logo: 'https://web.dev/favicon.ico'
        }
      ]
    }
  ];

  return (
    <section id="beginners" className="py-20 bg-gradient-to-b from-gray-800 to-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <span className="inline-block px-3 py-1 text-sm font-semibold text-indigo-400 bg-indigo-900/50 rounded-full mb-4">
            FOR BEGINNERS
          </span>
          <h2 className="text-3xl font-bold text-white mb-4">
            Start Your Coding Journey
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Hand-picked resources perfect for beginners starting their programming journey
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {beginnerResources.map((category, index) => (
            <div key={index} className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 hover:shadow-xl transition-all duration-300 border border-gray-700/50">
              <div className="flex items-center mb-4">
                {category.icon}
                <h3 className="text-xl font-semibold text-white ml-2">{category.title}</h3>
              </div>
              <ul className="space-y-3">
                {category.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center space-x-2 text-indigo-300 hover:text-indigo-200 transition-colors duration-200 group"
                    >
                      <img 
                        src={link.logo} 
                        alt={`${link.name} logo`} 
                        className="w-4 h-4 rounded-sm group-hover:scale-110 transition-transform duration-200"
                      />
                      <span>{link.name}</span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BeginnerSection;