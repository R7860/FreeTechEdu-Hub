import React, { useState } from 'react';
import { Book, Code2, Database, Network, Lock, Brain, Server, Globe } from 'lucide-react';
import { motion } from 'framer-motion';
import CodePreview from './CodePreview';

const NotesSection = () => {
  const [selectedLanguage, setSelectedLanguage] = useState<'en' | 'hi'>('en');
  const [selectedTopic, setSelectedTopic] = useState('dsa');

  const topics = [
    { id: 'dsa', name: { en: 'Data Structures', hi: 'डेटा स्ट्रक्चर्स' }, icon: <Code2 className="w-5 h-5" /> },
    { id: 'algo', name: { en: 'Algorithms', hi: 'एल्गोरिथम' }, icon: <Brain className="w-5 h-5" /> },
    { id: 'db', name: { en: 'Databases', hi: 'डेटाबेस' }, icon: <Database className="w-5 h-5" /> },
    { id: 'net', name: { en: 'Networks', hi: 'नेटवर्क' }, icon: <Network className="w-5 h-5" /> },
    { id: 'os', name: { en: 'Operating Systems', hi: 'ऑपरेटिंग सिस्टम' }, icon: <Server className="w-5 h-5" /> },
    { id: 'web', name: { en: 'Web Dev', hi: 'वेब डेवलपमेंट' }, icon: <Globe className="w-5 h-5" /> },
    { id: 'sec', name: { en: 'Security', hi: 'सुरक्षा' }, icon: <Lock className="w-5 h-5" /> }
  ];

  const notes = {
    dsa: {
      en: {
        title: "Data Structures Quick Notes",
        content: [
          {
            subtitle: "Arrays",
            text: "A linear data structure that stores elements in contiguous memory locations.",
            code: `// Array operations in JavaScript
const arr = [1, 2, 3];
arr.push(4);    // Add to end: O(1)
arr.pop();      // Remove from end: O(1)
arr.unshift(0); // Add to start: O(n)
arr.shift();    // Remove from start: O(n)`,
            keyPoints: [
              "Access: O(1)",
              "Search: O(n)",
              "Insertion: O(n)",
              "Deletion: O(n)"
            ]
          },
          {
            subtitle: "Linked Lists",
            text: "A linear data structure where elements are stored in nodes, each pointing to the next node.",
            code: `class Node {
  constructor(data) {
    this.data = data;
    this.next = null;
  }
}

class LinkedList {
  constructor() {
    this.head = null;
  }
  
  append(data) {
    const newNode = new Node(data);
    if (!this.head) {
      this.head = newNode;
      return;
    }
    let current = this.head;
    while (current.next) {
      current = current.next;
    }
    current.next = newNode;
  }
}`,
            keyPoints: [
              "Access: O(n)",
              "Search: O(n)",
              "Insertion at beginning: O(1)",
              "Deletion at beginning: O(1)"
            ]
          }
        ]
      },
      hi: {
        title: "डेटा स्ट्रक्चर्स त्वरित नोट्स",
        content: [
          {
            subtitle: "एरे (Array)",
            text: "एक लीनियर डेटा स्ट्रक्चर जो एलिमेंट्स को क्रमागत मेमोरी लोकेशन में स्टोर करता है।",
            code: `// जावास्क्रिप्ट में एरे ऑपरेशंस
const arr = [1, 2, 3];
arr.push(4);    // अंत में जोड़ें: O(1)
arr.pop();      // अंत से हटाएं: O(1)
arr.unshift(0); // शुरू में जोड़ें: O(n)
arr.shift();    // शुरू से हटाएं: O(n)`,
            keyPoints: [
              "एक्सेस: O(1)",
              "सर्च: O(n)",
              "इन्सर्शन: O(n)",
              "डिलीशन: O(n)"
            ]
          },
          {
            subtitle: "लिंक्ड लिस्ट",
            text: "एक लीनियर डेटा स्ट्रक्चर जहां एलिमेंट्स नोड्स में स्टोर होते हैं, प्रत्येक अगले नोड को पॉइंट करता है।",
            code: `class Node {
  constructor(data) {
    this.data = data;
    this.next = null;
  }
}

class LinkedList {
  constructor() {
    this.head = null;
  }
  
  append(data) {
    const newNode = new Node(data);
    if (!this.head) {
      this.head = newNode;
      return;
    }
    let current = this.head;
    while (current.next) {
      current = current.next;
    }
    current.next = newNode;
  }
}`,
            keyPoints: [
              "एक्सेस: O(n)",
              "सर्च: O(n)",
              "शुरू में इन्सर्शन: O(1)",
              "शुरू से डिलीशन: O(1)"
            ]
          }
        ]
      }
    }
    // More topics can be added here
  };

  const currentNotes = notes[selectedTopic as keyof typeof notes]?.[selectedLanguage];

  return (
    <section className="py-20 bg-gradient-to-b from-gray-900 via-gray-800 to-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-center space-x-4 mb-8">
          <button
            onClick={() => setSelectedLanguage('en')}
            className={`px-4 py-2 rounded-lg transition-all ${
              selectedLanguage === 'en'
                ? 'bg-indigo-600 text-white'
                : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
            }`}
          >
            English
          </button>
          <button
            onClick={() => setSelectedLanguage('hi')}
            className={`px-4 py-2 rounded-lg transition-all ${
              selectedLanguage === 'hi'
                ? 'bg-indigo-600 text-white'
                : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
            }`}
          >
            हिंदी
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-7 gap-6 mb-12">
          {topics.map((topic) => (
            <motion.button
              key={topic.id}
              onClick={() => setSelectedTopic(topic.id)}
              className={`flex items-center justify-center space-x-2 p-4 rounded-lg transition-all ${
                selectedTopic === topic.id
                  ? 'bg-indigo-600 text-white'
                  : 'bg-gray-800/50 text-gray-400 hover:bg-gray-700/50'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {topic.icon}
              <span>{topic.name[selectedLanguage]}</span>
            </motion.button>
          ))}
        </div>

        {currentNotes && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="space-y-8"
          >
            <h2 className="text-3xl font-bold text-white text-center mb-8">
              {currentNotes.title}
            </h2>
            
            {currentNotes.content.map((section, index) => (
              <div
                key={index}
                className="bg-gray-800/50 rounded-xl p-6 backdrop-blur-sm border border-gray-700/50"
              >
                <h3 className="text-xl font-semibold text-white mb-4">
                  {section.subtitle}
                </h3>
                <p className="text-gray-300 mb-4">{section.text}</p>
                
                <div className="mb-4">
                  <CodePreview
                    code={section.code}
                    language="javascript"
                    title={`${section.subtitle} Example`}
                  />
                </div>
                
                <div className="bg-gray-900/50 rounded-lg p-4">
                  <h4 className="text-white font-medium mb-2">Key Points:</h4>
                  <ul className="list-disc list-inside text-gray-300 space-y-1">
                    {section.keyPoints.map((point, i) => (
                      <li key={i}>{point}</li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </motion.div>
        )}
      </div>
    </section>
  );
};

export default NotesSection;