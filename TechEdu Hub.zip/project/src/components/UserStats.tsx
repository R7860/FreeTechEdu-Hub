import React from 'react';
import { motion } from 'framer-motion';
import { Star, Users, Activity, Award } from 'lucide-react';

const UserStats = () => {
  const stats = [
    {
      icon: <Users className="w-5 h-5" />,
      value: "10K+",
      label: "Active Users",
      color: "text-blue-400"
    },
    {
      icon: <Star className="w-5 h-5" />,
      value: "4.9",
      label: "User Rating",
      color: "text-yellow-400"
    },
    {
      icon: <Activity className="w-5 h-5" />,
      value: "98%",
      label: "Success Rate",
      color: "text-green-400"
    },
    {
      icon: <Award className="w-5 h-5" />,
      value: "150+",
      label: "Daily Sessions",
      color: "text-purple-400"
    }
  ];

  return (
    <div className="py-8">
      <motion.div 
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              className="bg-gray-800/40 backdrop-blur-sm rounded-xl p-4 text-center border border-gray-700/50"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.05 }}
            >
              <div className={`flex justify-center mb-2 ${stat.color}`}>
                {stat.icon}
              </div>
              <motion.div
                className="text-2xl font-bold text-white mb-1"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 + index * 0.1 }}
              >
                {stat.value}
              </motion.div>
              <div className="text-sm text-gray-400">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
};

export default UserStats;