import React from 'react';
import { Code2, Terminal, Globe, Server } from 'lucide-react';

const CompilerSection = () => {
  const compilers = [
    {
      title: 'Online IDEs',
      icon: <Code2 className="w-6 h-6 text-indigo-400" />,
      links: [
        { 
          name: 'CodePen',
          url: 'https://codepen.io',
          logo: 'https://cpwebassets.codepen.io/assets/favicon/favicon-touch-de50acbf5d634ec6791894eba4ba9cf490f709b3d742597c6fc4b734e6492a5a.png'
        },
        { 
          name: 'JSFiddle',
          url: 'https://jsfiddle.net',
          logo: 'https://jsfiddle.net/img/favicon.png'
        },
        { 
          name: 'CodeSandbox',
          url: 'https://codesandbox.io',
          logo: 'https://codesandbox.io/favicon.ico'
        }
      ]
    },
    {
      title: 'Programming Languages',
      icon: <Terminal className="w-6 h-6 text-indigo-400" />,
      links: [
        { 
          name: 'Replit',
          url: 'https://replit.com',
          logo: 'https://replit.com/public/icons/favicon-196.png'
        },
        { 
          name: 'OnlineGDB',
          url: 'https://www.onlinegdb.com',
          logo: 'https://www.onlinegdb.com/favicon.ico'
        },
        { 
          name: 'Programiz',
          url: 'https://www.programiz.com/python-programming/online-compiler/',
          logo: 'https://www.programiz.com/favicon.ico'
        }
      ]
    },
    {
      title: 'Web Development',
      icon: <Globe className="w-6 h-6 text-indigo-400" />,
      links: [
        { 
          name: 'StackBlitz',
          url: 'https://stackblitz.com',
          logo: 'https://c.staticblitz.com/assets/favicon-7453cf0c.png'
        },
        { 
          name: 'Glitch',
          url: 'https://glitch.com',
          logo: 'https://glitch.com/favicon.ico'
        },
        { 
          name: 'CodePen Projects',
          url: 'https://codepen.io/projects',
          logo: 'https://cpwebassets.codepen.io/assets/favicon/favicon-touch-de50acbf5d634ec6791894eba4ba9cf490f709b3d742597c6fc4b734e6492a5a.png'
        }
      ]
    },
    {
      title: 'Specialized Tools',
      icon: <Server className="w-6 h-6 text-indigo-400" />,
      links: [
        { 
          name: 'SQLFiddle',
          url: 'http://sqlfiddle.com',
          logo: 'http://sqlfiddle.com/favicon.ico'
        },
        { 
          name: 'RegExr',
          url: 'https://regexr.com',
          logo: 'https://regexr.com/assets/favicon.png'
        },
        { 
          name: 'TypeScript Playground',
          url: 'https://www.typescriptlang.org/play',
          logo: 'https://www.typescriptlang.org/favicon-32x32.png'
        }
      ]
    }
  ];

  return (
    <section id="compilers" className="py-20 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-white text-center mb-12">
          Online Compilers & IDEs
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {compilers.map((category, index) => (
            <div key={index} className="bg-gray-800 rounded-xl p-6 hover:shadow-xl transition-all duration-300">
              <div className="flex items-center mb-4">
                {category.icon}
                <h3 className="text-xl font-semibold text-white ml-2">{category.title}</h3>
              </div>
              <ul className="space-y-3">
                {category.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center space-x-2 text-indigo-300 hover:text-indigo-200 transition-colors duration-200"
                    >
                      <img 
                        src={link.logo} 
                        alt={`${link.name} logo`} 
                        className="w-4 h-4 rounded-sm"
                      />
                      <span>{link.name}</span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CompilerSection;