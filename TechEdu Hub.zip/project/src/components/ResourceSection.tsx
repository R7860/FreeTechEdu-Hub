import React from 'react';
import { BookOpen, Code, Brain, Laptop } from 'lucide-react';

const ResourceSection = () => {
  const resources = [
    {
      title: 'Learning Platforms',
      icon: <BookOpen className="w-6 h-6 text-indigo-400" />,
      links: [
        { name: 'freeCodeCamp', url: 'https://www.freecodecamp.org' },
        { name: 'The Odin Project', url: 'https://www.theodinproject.com' },
        { name: 'MIT OpenCourseWare', url: 'https://ocw.mit.edu' },
      ]
    },
    {
      title: 'Coding Practice',
      icon: <Code className="w-6 h-6 text-indigo-400" />,
      links: [
        { name: 'LeetCode', url: 'https://leetcode.com' },
        { name: 'HackerRank', url: 'https://www.hackerrank.com' },
        { name: 'CodeWars', url: 'https://www.codewars.com' },
      ]
    },
    {
      title: 'AI Tools',
      icon: <Brain className="w-6 h-6 text-indigo-400" />,
      links: [
        { name: 'GitHub Copilot', url: 'https://github.com/features/copilot' },
        { name: 'ChatGPT', url: 'https://chat.openai.com' },
        { name: 'Google Colab', url: 'https://colab.research.google.com' },
      ]
    },
    {
      title: 'Online IDEs',
      icon: <Laptop className="w-6 h-6 text-indigo-400" />,
      links: [
        { name: 'StackBlitz', url: 'https://stackblitz.com' },
        { name: 'CodeSandbox', url: 'https://codesandbox.io' },
        { name: 'Replit', url: 'https://replit.com' },
      ]
    }
  ];

  return (
    <section id="resources" className="py-20 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-white text-center mb-12">
          Free Learning Resources
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {resources.map((category, index) => (
            <div key={index} className="bg-gray-800 rounded-xl p-6 hover:shadow-xl transition-all duration-300">
              <div className="flex items-center mb-4">
                {category.icon}
                <h3 className="text-xl font-semibold text-white ml-2">{category.title}</h3>
              </div>
              <ul className="space-y-3">
                {category.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="resource-link"
                    >
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ResourceSection;